package br.com.projeto.estacioneaqui.models;

import java.util.Calendar;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "movimentacoes")
public class Movimentacao {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

//	@ManyToOne
//	@JoinColumn(name = "cliente_id", nullable = false)
//	private Cliente cliente;

//	@ManyToOne
//	@JoinColumn(name = "veiculo_id", nullable = false)
//	private Veiculo veiculo;

//	@ManyToOne
//	@JoinColumn(name = "vaga_id", nullable = false)
//	private Vaga vaga;
	
//	@ManyToOne
//	@JoinColumn(name = "servico_id", nullable = false)
//	private Servico servico;

	private Calendar entrada;

	private Calendar saida;

	private Double valor;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

//	public Cliente getCliente() {
//		return cliente;
//	}
//
//	public void setCliente(Cliente cliente) {
//		this.cliente = cliente;
//	}
//
//	public Veiculo getVeiculo() {
//		return veiculo;
//	}
//
//	public void setVeiculo(Veiculo veiculo) {
//		this.veiculo = veiculo;
//	}
//
//	public Vaga getVaga() {
//		return vaga;
//	}
//
//	public void setVaga(Vaga vaga) {
//		this.vaga = vaga;
//	}

	public Calendar getEntrada() {
		return entrada;
	}

	public void setEntrada(Calendar entrada) {
		this.entrada = entrada;
	}

	public Calendar getSaida() {
		return saida;
	}

	public void setSaida(Calendar saida) {
		this.saida = saida;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

}
