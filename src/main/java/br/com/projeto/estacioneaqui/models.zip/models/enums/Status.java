package br.com.projeto.estacioneaqui.models.enums;

public enum Status {
	OCUPADA, LIVRE;
}
